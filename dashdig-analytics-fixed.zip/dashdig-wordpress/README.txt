=== Dashdig Analytics ===
Contributors: dashdig
Tags: analytics, tracking, insights, ai, statistics
Requires at least: 6.0
Tested up to: 6.4
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Powerful analytics tracking with AI-powered insights for your WordPress site.

== Description ==

Dashdig Analytics brings powerful, AI-driven analytics to your WordPress site. Track visitor behavior, understand your audience, and get intelligent recommendations to improve your website's performance.

**Key Features:**

* 📊 **Real-time Analytics** - Monitor your website traffic in real-time
* 🤖 **AI-Powered Insights** - Get intelligent recommendations based on your data
* 📈 **Advanced Metrics** - Track page views, visitors, bounce rate, and session duration
* 🎯 **Event Tracking** - Automatically track clicks, forms, and scroll depth
* 🔒 **Privacy-Focused** - GDPR compliant with built-in consent management
* ⚡ **Lightweight** - Minimal impact on site performance
* 🎨 **Beautiful Dashboard** - Clean, intuitive interface in WordPress admin

**What You Can Track:**

* Page views and unique visitors
* Click events on links and buttons
* Form submissions
* Scroll depth and engagement
* Session duration and bounce rate
* Traffic sources and referrers
* Device and browser information

**AI-Powered Insights:**

Dashdig uses artificial intelligence to analyze your data and provide actionable recommendations:

* Identify high-performing content
* Discover optimization opportunities
* Understand user behavior patterns
* Get content strategy suggestions
* Receive personalized growth tips

**Integration:**

Seamlessly integrates with:

* Dashdig URL Shortener
* Dashdig Dashboard
* WordPress REST API
* Popular page builders
* WooCommerce (coming soon)

== Installation ==

**Automatic Installation:**

1. Log in to your WordPress admin panel
2. Go to Plugins > Add New
3. Search for "Dashdig Analytics"
4. Click "Install Now" and then "Activate"

**Manual Installation:**

1. Download the plugin ZIP file
2. Log in to your WordPress admin panel
3. Go to Plugins > Add New > Upload Plugin
4. Choose the ZIP file and click "Install Now"
5. Activate the plugin

**Configuration:**

1. Go to Dashdig > Settings in your WordPress admin
2. Sign up for a free account at [dashdig.com](https://dashdig.com)
3. Get your Tracking ID and API Key from the Dashdig dashboard
4. Enter your credentials in the plugin settings
5. Enable tracking and save changes
6. Visit Dashdig > Dashboard to view your analytics

== Frequently Asked Questions ==

= Do I need a Dashdig account? =

Yes, you'll need a free Dashdig account to use this plugin. Sign up at [dashdig.com](https://dashdig.com).

= Is this GDPR compliant? =

Yes, Dashdig Analytics is designed with privacy in mind and includes features for GDPR compliance, including consent management and data anonymization.

= Will this slow down my website? =

No, Dashdig Analytics is lightweight and optimized for performance. It loads asynchronously and has minimal impact on page load times.

= Can I track custom events? =

Yes! You can use the JavaScript API to track custom events. See the documentation for details.

= Does this work with caching plugins? =

Yes, Dashdig Analytics works with all major caching plugins including WP Rocket, W3 Total Cache, and WP Super Cache.

= Can I export my data? =

Yes, you can export all your analytics data from the Dashdig dashboard.

= Is there a free plan? =

Yes, Dashdig offers a generous free plan with up to 10,000 page views per month.

== Screenshots ==

1. Dashboard overview with real-time statistics
2. AI-powered insights and recommendations
3. Traffic analytics and charts
4. Settings page for easy configuration
5. Event tracking in action

== Changelog ==

= 1.0.0 =
* Initial release
* Real-time analytics tracking
* AI-powered insights
* Page view and visitor tracking
* Click and event tracking
* Scroll depth monitoring
* Form submission tracking
* WordPress admin dashboard
* Settings management
* Privacy controls
* API integration

== Upgrade Notice ==

= 1.0.0 =
Initial release of Dashdig Analytics. Track your website with powerful AI-driven insights!

== Privacy Policy ==

Dashdig Analytics collects the following data:

* Page URLs and titles
* Referrer information
* Device and browser type
* Geographic location (country/city)
* User interactions (clicks, scrolls, forms)
* Session duration

This data is used solely for analytics purposes and is never sold to third parties. Users can request data deletion at any time through the Dashdig dashboard.

For more information, see our [Privacy Policy](https://dashdig.com/privacy).

== Support ==

For support, visit:

* Documentation: [dashdig.com/docs](https://dashdig.com/docs)
* Support Forum: [dashdig.com/support](https://dashdig.com/support)
* Email: support@dashdig.com

== Credits ==

Developed by the Dashdig team with ❤️

== External Services ==

This plugin connects to the Dashdig API (https://dashdig-production.up.railway.app) to send analytics data and retrieve insights. By using this plugin, you agree to Dashdig's [Terms of Service](https://dashdig.com/terms) and [Privacy Policy](https://dashdig.com/privacy).


